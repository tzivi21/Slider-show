#!/usr/bin/env bash
# Runs a test command and prints only the signal: failures, stack traces, pass count.
# Usage: test_summary.sh "npm test"
set -uo pipefail

CMD="$1"
OUT=$(eval "$CMD" 2>&1)
STATUS=$?

if [ $STATUS -eq 0 ]; then
  # Try to pull a "N passed" style line if the runner prints one, else just confirm success.
  SUMMARY_LINE=$(echo "$OUT" | grep -Ei 'passed|ok|pass' | tail -1)
  echo "All tests passed. ${SUMMARY_LINE:-}"
  exit 0
fi

echo "=== TEST FAILURES ==="
# Grab lines around common failure markers (FAIL, Error, AssertionError, Traceback, at ...)
echo "$OUT" | grep -A 15 -iE 'FAIL|Error|AssertionError|Traceback' | head -200

echo
echo "=== Summary line ==="
echo "$OUT" | grep -Ei 'failed|failing|[0-9]+ passed' | tail -3

exit $STATUS
