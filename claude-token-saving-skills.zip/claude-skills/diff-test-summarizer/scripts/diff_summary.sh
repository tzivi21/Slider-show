#!/usr/bin/env bash
# Compact git diff: stat summary + changed hunks, collapsed context.
set -euo pipefail

echo "=== Changed files ==="
git diff --stat

echo
echo "=== Diff (compact) ==="
# -U1 = only 1 line of context around each change instead of default 3
# Strip blank/whitespace-only unchanged lines to cut noise further
git diff -U1 | grep -vE '^\s*$' || true
