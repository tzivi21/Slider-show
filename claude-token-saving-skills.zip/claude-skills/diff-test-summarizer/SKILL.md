---
name: diff-test-summarizer
description: Use whenever you need to look at git diffs, git status, or test/build output (npm test, pytest, cargo test, CI logs). Runs the raw command through a filtering script first so only the signal (changed lines, failing tests, stack traces) reaches context — never dump raw diff/test output directly.
effort: low
---

# Diff & Test Output Summarizer

Raw `git diff`, `git status -v`, and full test-runner output are one of the biggest token drains in daily coding sessions — mostly whitespace, unchanged context lines, and passing-test noise that adds nothing.

## Rule

Never run `git diff`, `git status`, or a full test suite directly and dump the raw output into context. Instead:

1. For git changes, run:
   ```bash
   bash scripts/diff_summary.sh
   ```
   This prints a compact stat summary (files changed, +/- counts) plus only the actually-changed hunks, with duplicate context lines collapsed.

2. For test output, run the test command piped through:
   ```bash
   bash scripts/test_summary.sh "<your test command>"
   ```
   Example: `bash scripts/test_summary.sh "npm test"` or `bash scripts/test_summary.sh "pytest"`.
   This filters to **failing tests only** — test name, assertion diff, and stack trace — and replaces a passing run with a one-line "N passed, 0 failed."

3. If a test fails, only include the relevant failure block in your response/reasoning — do not quote the full raw log back to the user.

## Why

A single `npm test` run can be thousands of lines. Claude only needs the failing test name, the expected vs. actual values, and the stack trace pointing at the file/line — everything else is noise that gets re-read on every subsequent turn of the session.

## Files
- `scripts/diff_summary.sh` — compact git diff
- `scripts/test_summary.sh` — filters test runner output to failures only
