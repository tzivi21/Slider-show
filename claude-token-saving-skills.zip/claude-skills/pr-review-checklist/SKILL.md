---
name: pr-review-checklist
description: Use before finalizing any code change, new function, or PR — runs a quick self-review checklist so mistakes get caught before the user has to ask for fixes. Saves tokens indirectly by avoiding "fix this too" follow-up turns.
---

# Pre-Commit / Pre-PR Self-Review Checklist

Before presenting a code change as finished, silently check it against this list. Only mention items that actually apply or that you fixed — don't narrate the whole checklist back to the user.

## Correctness
- [ ] Edge cases handled (empty input, null/undefined, zero, negative numbers, boundary indices)
- [ ] Error handling matches the codebase's existing pattern (exceptions vs. error returns vs. Result types — check a neighboring file if unsure)
- [ ] No obvious off-by-one, unclosed resource, or unhandled async rejection

## Consistency
- [ ] Naming matches existing conventions in the file/module (camelCase vs snake_case, prefixes, etc.)
- [ ] Imports/dependencies match what's already used elsewhere in the repo — don't introduce a new library for something an existing dependency already does
- [ ] Formatting matches the project's style (check for a linter/formatter config before guessing)

## Security (only for code touching user input, auth, or external calls)
- [ ] No string-concatenated SQL/shell commands — use parameterization
- [ ] No secrets, tokens, or credentials hardcoded
- [ ] User input validated/sanitized before use

## Tests
- [ ] If the project has a test suite, does this change need a new/updated test?
- [ ] Existing tests still pass (use the diff-test-summarizer skill to check, not a raw full run)

## Scope
- [ ] Change is limited to what was asked — no unrelated "drive-by" edits mixed in
- [ ] If the fix revealed a second, separate bug, flag it briefly rather than silently fixing it inline

---
**Customize this file** with your team's actual standards (specific linters, required test coverage, security policies) — this is a generic starting point.
