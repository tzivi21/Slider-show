---
name: repo-snapshot
description: Use when you need to understand an unfamiliar part of the codebase, onboard onto a new module, or answer "how does X work" / "where is Y implemented" questions. Builds one filtered, curated snapshot of the relevant code instead of exploring via many separate file reads and greps.
---

# Repo Snapshot (via repomix)

Instead of exploring a codebase through many individual `view`/`grep`/`find` calls — each of which adds a full round-trip and output to context — build one compact, filtered snapshot up front.

## Steps

1. Check if `repomix` is available:
   ```bash
   npx repomix --version
   ```
   If not installed, it can be run directly with `npx repomix` (no global install needed).

2. Scope the snapshot to the relevant directory instead of the whole repo:
   ```bash
   npx repomix --include "src/<relevant-module>/**" -o /tmp/snapshot.xml
   ```
   Adjust the `--include` glob to the module/feature in question. Only snapshot the whole repo if the question genuinely spans the entire codebase.

3. Read the generated snapshot file once (`/tmp/snapshot.xml` or `.md` depending on config) instead of reading each source file individually.

4. For very large modules, add `--compress` to strip comments/whitespace, or filter further with `--ignore` for generated files, vendored code, lockfiles, and build output.

## Why this saves tokens

One scoped snapshot read replaces N separate `view`/`grep` tool calls, each of which carries its own overhead (tool call + full file content + no deduplication across calls). Repomix also strips things like binary file noise, node_modules, and lockfiles automatically.

## When NOT to use this

- For a single, already-known file — just read it directly, don't invoke repomix for one file.
- For a targeted fix where you already know the exact function/file — go straight there instead of snapshotting.
