---
name: commit-message
description: Use whenever writing or suggesting a git commit message. Mechanical formatting task — low reasoning effort needed. Follows Conventional Commits style, kept short.
effort: low
---

# Commit Message Formatting

When asked to write, suggest, or generate a commit message:

1. Use **Conventional Commits** format:
   ```
   <type>(<scope>): <short summary, imperative mood, ≤72 chars>

   <optional body — only if the change needs explanation beyond the summary>
   ```
2. `<type>` is one of: `feat`, `fix`, `refactor`, `test`, `docs`, `chore`, `perf`, `style`, `build`, `ci`.
3. `<scope>` is the module/package/file area touched (e.g. `auth`, `parser`, `api`). Omit if the change is repo-wide.
4. Summary line: imperative mood ("add", "fix", "remove" — not "added"/"fixes"), no trailing period.
5. Only add a body if the *why* isn't obvious from the diff. Skip it for small, self-explanatory changes.
6. Never invent scope/detail not evidenced by the actual diff — base the message only on the changes shown.
7. Don't ask the user to confirm the message unless the change is ambiguous (e.g. touches multiple unrelated concerns — in that case, suggest splitting into separate commits instead of one long message).

## Example

```
fix(auth): correct token expiry check off-by-one

Expiry comparison used `<=` instead of `<`, causing valid tokens
to be rejected exactly at the expiry timestamp.
```
