---
name: terse-coding
description: Use for routine code edits, bug fixes, refactors, and small feature additions. Keeps responses short — diffs only, no restated code, no verbose explanations — to save output tokens on everyday coding tasks.
effort: low
---

# Terse Coding Output

When this skill applies, follow these output rules:

1. **Show diffs, not full files.** Only print the lines that changed, with a few lines of surrounding context. Never re-paste an entire file unless the user explicitly asks for the full file.
2. **No restating the plan before acting.** Skip "I will now..." preambles. Make the edit directly.
3. **No post-hoc summary paragraphs.** After an edit, one short line is enough (e.g. "Fixed the off-by-one in `parseRange`."). Do not re-explain what the diff already shows.
4. **Skip caveats/disclaimers unless relevant.** Don't add generic notes like "make sure to test this" unless there's a specific, non-obvious risk.
5. **No re-explaining unchanged code.** If a function wasn't touched, don't describe it.
6. **Ask, don't guess, only when truly ambiguous.** If scope is unclear, ask one short question instead of writing speculative code and explaining assumptions at length.

## When NOT to use this skill

- Architecture/design decisions, security-sensitive changes, or anything the user asked to be reviewed carefully — use normal, fuller explanations there instead.
- If the user asks "explain what this does" or "walk me through this" — that's a request for detail, not brevity.

## Example

**Instead of:**
> I've reviewed the function and identified the issue. The loop is using `<=` instead of `<`, which causes an off-by-one error. Here's the full corrected file: [200 lines]... This should now correctly handle the boundary condition. Let me know if you'd like me to add tests for this edge case.

**Do this:**
```diff
- for (let i = 0; i <= arr.length; i++) {
+ for (let i = 0; i < arr.length; i++) {
```
Fixed off-by-one in the loop bound.
